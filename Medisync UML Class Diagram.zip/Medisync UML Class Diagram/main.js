document.getElementById('diagram').innerHTML = buildDiagramSvg();
