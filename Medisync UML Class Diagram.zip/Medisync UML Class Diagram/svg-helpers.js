const SIZES = {
  lineHeight: 15,         
  classHeaderHeight: 28,  
  enumHeaderHeight: 40,   
  compartmentPadding: 8,  
  textInset: 8,           
};

function escapeXml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}


function textEl(x, y, content, { anchor = 'start', className = '' } = {}) {
  return `<text x="${x}" y="${y}" text-anchor="${anchor}" class="uml-text ${className}">${escapeXml(content)}</text>`;
}

function rectEl(x, y, width, height, className) {
  return `<rect x="${x}" y="${y}" width="${width}" height="${height}" class="${className}"/>`;
}

function lineEl(x1, y1, x2, y2) {
  return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" class="uml-line"/>`;
}

function polylineEl(points, { arrow = false } = {}) {
  const coords = points.map(([x, y]) => `${x},${y}`).join(' ');
  const marker = arrow ? ' marker-end="url(#open-arrow)"' : '';
  return `<polyline points="${coords}" class="uml-line"${marker}/>`;
}


function diamondHorizontal(x, y, { filled = false } = {}) {
  const points = `${x},${y} ${x + 8},${y - 5} ${x + 16},${y} ${x + 8},${y + 5}`;
  return `<polygon points="${points}" class="${diamondClass(filled)}"/>`;
}


function diamondVertical(x, y, { filled = false } = {}) {
  const points = `${x},${y} ${x + 5},${y + 8} ${x},${y + 16} ${x - 5},${y + 8}`;
  return `<polygon points="${points}" class="${diamondClass(filled)}"/>`;
}

function diamondClass(filled) {
  return filled ? 'uml-diamond uml-diamond-filled' : 'uml-diamond uml-diamond-hollow';
}


function classBox(name, x, y, width, { attributes = [], operations = [] }) {
  const { lineHeight, classHeaderHeight, compartmentPadding, textInset } = SIZES;

  const attributesHeight = attributes.length * lineHeight + compartmentPadding;
  const operationsHeight = operations.length ? operations.length * lineHeight + compartmentPadding : 0;
  const height = classHeaderHeight + attributesHeight + operationsHeight;

  let svg = rectEl(x, y, width, height, 'uml-box-body') + rectEl(x, y, width, classHeaderHeight, 'uml-box-head');
  svg += textEl(x + width / 2, y + 19, name, { anchor: 'middle', className: 'uml-title' });

  const attributesTop = y + classHeaderHeight;
  attributes.forEach((member, i) => {
    svg += textEl(x + textInset, attributesTop + 14 + i * lineHeight, member);
  });

  if (operations.length) {
    const dividerY = attributesTop + attributesHeight;
    svg += lineEl(x, dividerY, x + width, dividerY);
    operations.forEach((member, i) => {
      svg += textEl(x + textInset, dividerY + 14 + i * lineHeight, member);
    });
  }

  return { x, y, width, height, svg };
}

/** Enumeration box: «enumeration» stereotype, enum name, then the constants. */
function enumBox(name, x, y, width, values) {
  const { lineHeight, enumHeaderHeight, compartmentPadding, textInset } = SIZES;
  const height = enumHeaderHeight + values.length * lineHeight + compartmentPadding;

  let svg = rectEl(x, y, width, height, 'uml-box-body') + rectEl(x, y, width, enumHeaderHeight, 'uml-box-head');
  svg += textEl(x + width / 2, y + 15, '\u00ABenumeration\u00BB', { anchor: 'middle', className: 'uml-italic' });
  svg += textEl(x + width / 2, y + 32, name, { anchor: 'middle', className: 'uml-title' });

  values.forEach((value, i) => {
    svg += textEl(x + textInset, y + enumHeaderHeight + 14 + i * lineHeight, value);
  });

  return { x, y, width, height, svg };
}
