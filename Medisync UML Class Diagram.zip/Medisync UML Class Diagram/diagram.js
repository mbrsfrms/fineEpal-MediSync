const CANVAS_WIDTH = 680;
const MARGIN = 10;
const COLUMN_WIDTH = 270;
const TOP = 20;

const LEFT_X = MARGIN;
const RIGHT_X = CANVAS_WIDTH - MARGIN - COLUMN_WIDTH;
const GAP_START_X = LEFT_X + COLUMN_WIDTH;          
const GAP_END_X = RIGHT_X;                          
const GAP_MIDDLE_X = (GAP_START_X + GAP_END_X) / 2;

const DEFAULT_GAP = 50;                             
const EXTRA_GAP_AFTER = { Medication: 56 };         

const LEFT_COLUMN = ['User', 'Patient'];
const RIGHT_COLUMN = ['UserProfile', 'Medication', 'IntakeLog', 'Allergy', 'HealthReminder', 'ReminderSetting'];


const PATIENT_OWNS = [
  { target: 'Allergy',         startOffset: 145, turnX: 364, label: 'has',        targetMultiplicity: '*' },
  { target: 'HealthReminder',  startOffset: 168, turnX: 340, label: 'has',        targetMultiplicity: '*' },
  { target: 'ReminderSetting', startOffset: 186, turnX: 316, label: 'configures', targetMultiplicity: '0..1' },
];

const bottomOf = (box) => box.y + box.height;


function placeColumn(classNames, x) {
  const placed = {};
  let y = TOP;
  classNames.forEach((name) => {
    const box = classBox(name, x, y, COLUMN_WIDTH, CLASSES[name]);
    placed[name] = box;
    y = bottomOf(box) + (EXTRA_GAP_AFTER[name] ?? DEFAULT_GAP);
  });
  return placed;
}


function userHasProfile({ User }) {
  const y = User.y + 40;
  return polylineEl([[GAP_START_X, y], [GAP_END_X, y]], { arrow: true })
    + textEl(GAP_START_X + 6, y - 6, '1')
    + textEl(GAP_MIDDLE_X, y - 6, 'has', { anchor: 'middle' })
    + textEl(GAP_END_X - 6, y - 6, '0..1', { anchor: 'end' });
}


function userCaresForPatient({ User, Patient }) {
  const x = LEFT_X + COLUMN_WIDTH / 2;
  const top = bottomOf(User);
  return polylineEl([[x, top], [x, Patient.y]], { arrow: true })
    + textEl(x - 6, top + 13, '1', { anchor: 'end' })
    + textEl(x + 6, top + 29, 'cares for')
    + textEl(x - 6, Patient.y - 5, '*', { anchor: 'end' });
}


function profileActivePatient({ Patient }) {
  const y = Patient.y + 24;
  return polylineEl([[GAP_END_X, y], [GAP_START_X, y]], { arrow: true })
    + textEl(GAP_MIDDLE_X, y - 6, 'active patient', { anchor: 'middle' })
    + textEl(GAP_START_X + 16, y - 6, '0..1')
    + textEl(GAP_END_X - 6, y - 6, '0..1', { anchor: 'end' });
}


function patientTakesMedication({ Patient }) {
  const y = Patient.y + 115;
  return diamondHorizontal(GAP_START_X, y)
    + lineEl(GAP_START_X + 16, y, GAP_END_X, y)
    + textEl(GAP_START_X + 20, y - 5, '0..1')
    + textEl((GAP_START_X + 16 + GAP_END_X) / 2, y - 5, 'takes', { anchor: 'middle' })
    + textEl(GAP_END_X - 6, y - 5, '*', { anchor: 'end' });
}


function patientOwns(boxes, { target, startOffset, turnX, label, targetMultiplicity }) {
  const startY = boxes.Patient.y + startOffset;
  const endY = boxes[target].y + 46;             
  return diamondHorizontal(GAP_START_X, startY)
    + polylineEl([[GAP_START_X + 16, startY], [turnX, startY], [turnX, endY], [GAP_END_X, endY]])
    + textEl(GAP_START_X + 20, startY - 5, '0..1')
    + textEl((turnX + GAP_END_X) / 2, endY - 5, label, { anchor: 'middle' })
    + textEl(GAP_END_X - 6, endY + 14, targetMultiplicity, { anchor: 'end' });
}


function medicationLogs({ Medication, IntakeLog }) {
  const x = RIGHT_X + COLUMN_WIDTH / 2;
  const bottom = bottomOf(Medication);
  return diamondVertical(x, bottom, { filled: true })
    + lineEl(x, bottom + 16, x, IntakeLog.y)
    + textEl(x + 8, bottom + 30, '1')
    + textEl(x - 8, bottom + 34, 'logged as', { anchor: 'end' })
    + textEl(x + 8, IntakeLog.y - 5, '*');
}


function enumerationBlock(startY) {
  let svg = textEl(LEFT_X, startY, 'Enumerations (field types)', { className: 'uml-title' });
  let y = startY + 12;
  ENUMS.forEach(({ name, values }) => {
    const box = enumBox(name, LEFT_X, y, COLUMN_WIDTH, values);
    svg += box.svg;
    y = bottomOf(box) + 10;
  });
  return { svg, bottom: y };
}



function buildDiagramSvg() {
  const boxes = { ...placeColumn(LEFT_COLUMN, LEFT_X), ...placeColumn(RIGHT_COLUMN, RIGHT_X) };
  const enums = enumerationBlock(bottomOf(boxes.Patient) + 44);
  const height = Math.max(bottomOf(boxes.ReminderSetting), enums.bottom) + 20;

  const classShapes = Object.values(boxes).map((box) => box.svg).join('');
  const connectors = [
    userHasProfile(boxes),
    userCaresForPatient(boxes),
    profileActivePatient(boxes),
    patientTakesMedication(boxes),
    ...PATIENT_OWNS.map((spec) => patientOwns(boxes, spec)),
    medicationLogs(boxes),
  ].join('');

  const defs = `<defs>
    <marker id="open-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="9" markerHeight="9" orient="auto">
      <path d="M1,1 L9,5 L1,9" class="uml-arrow"/>
    </marker>
  </defs>`;

  return `<svg viewBox="0 0 ${CANVAS_WIDTH} ${height}" xmlns="http://www.w3.org/2000/svg" role="img"
      aria-label="UML class diagram of the MediSync data model">
    ${defs}
    <rect x="0" y="0" width="${CANVAS_WIDTH}" height="${height}" class="uml-background"/>
    ${classShapes}${connectors}${enums.svg}
  </svg>`;
}
