const CLASSES = {
  User: {
    attributes: [
      '-id : String',
      '-fullName : String',
      '-role : Role',
    ],
    operations: [],
  },

  UserProfile: {
    attributes: [
      '-id : String',
      '-createdById : String',
      '-mode : Mode',
      '-fullName : String',
      '-dateOfBirth : LocalDate',
      '-activePatientId : String',
      '-onboardingComplete : boolean',
    ],
    operations: [
      '+setMode(mode)',
      '+setActivePatient(patientId)',
    ],
  },

  Patient: {
    attributes: [
      '-id : String',
      '-createdById : String',
      '-name : String',
      '-category : Category',
      '-dateOfBirth : LocalDate',
      '-ageYears : Integer',
      '-relationship : String',
      '-notes : String',
    ],
    operations: [
      '+ageLabel() : String',
      '+categoryLabel() : String',
    ],
  },

  Medication: {
    attributes: [
      '-id : String',
      '-createdById : String',
      '-patientId : String',
      '-patientName : String',
      '-name : String',
      '-dosage : String',
      '-form : Form',
      '-frequency : Frequency',
      '-intakeTimes : List<LocalTime>',
      '-startDate : LocalDate',
      '-endDate : LocalDate',
      '-quantity : Double',
      '-remaining : Double',
      '-lowStockThreshold : Double',
      '-instructions : String',
      '-notes : String',
      '-status : MedStatus',
    ],
    operations: [
      '+dosesPerDay() : int',
      '+daysOfSupply() : Integer',
      '+supplyInfo() : SupplyInfo',
      '+isActiveOn(date) : boolean',
      '+doseSlots(date) : List<DoseSlot>',
    ],
  },

  IntakeLog: {
    attributes: [
      '-id : String',
      '-createdById : String',
      '-medicationId : String',
      '-medicationName : String',
      '-dosage : String',
      '-form : String',
      '-patientId : String',
      '-patientName : String',
      '-scheduledDate : LocalDate',
      '-scheduledTime : LocalTime',
      '-status : IntakeStatus',
      '-recordedAt : LocalDateTime',
      '-notes : String',
    ],
    operations: [
      '+intakeTiming() : Timing',
    ],
  },

  Allergy: {
    attributes: [
      '-id : String',
      '-createdById : String',
      '-patientId : String',
      '-patientName : String',
      '-allergen : String',
      '-kind : AllergyKind',
      '-severity : Severity',
      '-reaction : String',
      '-notes : String',
    ],
    operations: [
      '+matchesMedication(med) : boolean',
    ],
  },

  HealthReminder: {
    attributes: [
      '-id : String',
      '-createdById : String',
      '-patientId : String',
      '-patientName : String',
      '-title : String',
      '-kind : ReminderKind',
      '-reminderDate : LocalDate',
      '-reminderTime : LocalTime',
      '-notes : String',
      '-completed : boolean',
    ],
    operations: [
      '+isOverdue(date) : boolean',
    ],
  },

  ReminderSetting: {
    attributes: [
      '-id : String',
      '-createdById : String',
      '-patientId : String',
      '-patientName : String',
      '-medicationReminders : boolean',
      '-lowSupplyAlerts : boolean',
      '-refillReminders : boolean',
      '-followupReminders : boolean',
      '-reminderTime : LocalTime',
    ],
    operations: [],
  },
};

const ENUMS = [
  { name: 'Role',         values: ['ADMIN', 'USER'] },
  { name: 'Mode',         values: ['SELF', 'GUARDIAN'] },
  { name: 'Category',     values: ['CHILD', 'ELDERLY'] },
  { name: 'Form',         values: ['TABLET', 'CAPSULE', 'LIQUID', 'DROPS', 'INJECTION', 'INHALER', 'CREAM', 'OTHER'] },
  { name: 'Frequency',    values: ['ONCE_DAILY', 'TWICE_DAILY', 'THREE_TIMES_DAILY', 'FOUR_TIMES_DAILY', 'EVERY_OTHER_DAY', 'WEEKLY', 'AS_NEEDED'] },
  { name: 'MedStatus',    values: ['ACTIVE', 'COMPLETED', 'DISCONTINUED'] },
  { name: 'IntakeStatus', values: ['TAKEN', 'MISSED', 'SKIPPED'] },
  { name: 'Timing',       values: ['ON_TIME', 'LATE'] },
  { name: 'AllergyKind',  values: ['MEDICATION', 'FOOD', 'ENVIRONMENTAL', 'OTHER'] },
  { name: 'Severity',     values: ['MILD', 'MODERATE', 'SEVERE'] },
  { name: 'ReminderKind', values: ['FOLLOW_UP', 'APPOINTMENT', 'CHECKUP', 'OTHER'] },
];
